package com.barbershop.daily.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.barbershop.daily.data.Session
import com.barbershop.daily.data.SheetsRepository
import com.barbershop.daily.data.TodayData
import kotlinx.coroutines.launch
import androidx.compose.ui.unit.dp

fun AdminScreen(session: Session) {
    val scope = rememberCoroutineScope()
    var tabName by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var data by remember { mutableStateOf<TodayData?>(null) }

fun AdminScreen() {
    Surface(Modifier.fillMaxSize().padding(16.dp)) {
        Column {
            Text("Admin", style = MaterialTheme.typography.headlineSmall)

            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = tabName,
                onValueChange = { tabName = it },
                label = { Text("View a day tab (e.g., Wed 03 Jun 2026)") }
            )
            Spacer(Modifier.height(8.dp))
            Button(
                enabled = !loading && tabName.isNotBlank(),
                onClick = {
                    loading = true
                    error = null
                    scope.launch {
                        try {
                            data = SheetsRepository.adminListDay(session.token, tabName.trim())
                        } catch (t: Throwable) {
                            error = t.message ?: "Failed"
                        } finally {
                            loading = false
                        }
                    }
                }
            ) { Text(if (loading) "Loading..." else "Load") }

            if (error != null) {
                Spacer(Modifier.height(8.dp))
                Text(error!!, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(12.dp))
            if (data != null) {
                Text("Transactions", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                LazyColumn {
                    items(data!!.transactions) { tx ->
                        Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text("${tx.clientName} — ${tx.amount.toInt()}", style = MaterialTheme.typography.titleMedium)
                                Text("Served by: ${tx.servedBy}")
                                Text("Pay: ${tx.payMethod} | Status: ${tx.status} | Mpesa to: ${tx.mpesaTo}")
                                if (tx.lastEditor.isNotBlank()) Text(tx.lastEditor, style = MaterialTheme.typography.bodySmall)
                                Text("By: ${tx.createdBy} | ${tx.createdAt}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            )
        }
    }
